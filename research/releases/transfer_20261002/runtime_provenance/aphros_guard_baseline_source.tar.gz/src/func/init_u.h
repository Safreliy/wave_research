// Created by Petr Karnakov on 25.04.2018
// Copyright 2018 ETH Zurich

#pragma once

#include <cmath>
#include <functional>
#include <iostream>
#include <iterator>
#include <limits>
#include <sstream>
#include <stdexcept>

#include "debug/isnan.h"
#include "dump/hdf.h"
#include "dump/raw.h"
#include "geom/block.h"
#include "geom/field.h"
#include "geom/vect.h"
#include "parse/vars.h"
#include "primlist.h"
#include "solver/multi.h"
#include "solver/reconst.h"

// Returns volume fraction of cell overlapping with positive levelset.
// levelset: levelset function, =0 on interface.
// xc: cell center
// h: cell size
template <class Scal, size_t dim>
static Scal GetLevelSetVolume(
    std::function<Scal(const generic::Vect<Scal, dim>&)> levelset,
    const generic::Vect<Scal, dim>& xc, const generic::Vect<Scal, dim>& h) {
  using Vect = generic::Vect<Scal, dim>;
  using MIdx = generic::Vect<IntIdx, dim>;

  const Scal dx = 1e-3; // Step to compute gradient relative to h.

  const GBlock<size_t, dim> b(MIdx(2));
  const Scal lxc = levelset(xc);
  // Traverse nodes of the cell.
  for (auto w : b) {
    const Vect xn = xc + (Vect(w) - Vect(0.5)) * h; // Cell node.
    if ((lxc > 0) != (levelset(xn) > 0)) { // Cell is crossed by interface.
      // Linear approximation:
      //   levelset(x) = levelset(xc) + (x - xc).dot(grad(levelset, xc))
      Vect normal;
      for (size_t d = 0; d < dim; ++d) {
        Vect xp(xc), xm(xc);
        const Scal dxh = dx * h[d];
        xp[d] += dxh * 0.5;
        xm[d] -= dxh * 0.5;
        normal[d] = (levelset(xp) - levelset(xm)) / dxh;
      }
      return Reconst<Scal>::GetLineU(normal, lxc, h);
    }
  }

  return lxc > 0. ? 1. : 0.;
}

// Returns point at which interpolant has value 0.
// x0,x1: points
// f0,f1: values
template <class Scal, class Vect>
Vect GetIso(Vect x0, Vect x1, Scal f0, Scal f1) {
  return (x0 * f1 - x1 * f0) / (f1 - f0);
}

template <class Scal>
Scal GetPositiveEdgeFraction(Scal l0, Scal l1);

// Returns fraction of face area for which ls>0.
// ee: fraction of edge length for which ls>0
//       3
//   -------
//  0|     |
//   |     | 2
//   -------
//     1
template <class Scal>
Scal GetFaceAreaFraction(std::array<Scal, 4> ee);

// Returns face field containing face area for which ls > 0.
// fnl: level-set function ls on nodes [i]
template <class M>
FieldFace<typename M::Scal> GetPositiveAreaFraction(
    const FieldNode<typename M::Scal>& fnl, const M& m);

// Returns volume fraction field field from level-set function on nodes.
// fnl: level-set function computed on nodes [i]
template <class M>
FieldCell<typename M::Scal> GetPositiveVolumeFraction(
    const FieldNode<typename M::Scal>& fnl, const M& m);

// Fills volume fraction field from list of primitives.
// fc: field to fill
// primlist: list of primitives
// edim: effective dimension
// approx: 0: stepwise, 1: level-set, 2: overlap, 3: level-set on nodes
template <class M>
void InitVfList(
    FieldCell<typename M::Scal>& fc, std::istream& primlist, int approx,
    size_t edim, const M& m, bool verbose);

// Returns an initialized of the volume fraction field.
// par: parameters
// M: mesh
// Returns:
// std::function<void(GField<Cell>& fc,const M& m)>
// fc: field to fill [i]
// m: mesh
template <class M>
std::function<void(FieldCell<typename M::Scal>&, const M&)> CreateInitU(
    const Vars& par, bool verb);

// Reads list of primitives from either file `list_path`
// or inline if "inline" is the first word of `list_path`
std::stringstream ReadPrimList(std::string list_path, bool verbose);

template <class M>
void InitVf(
    FieldCell<typename M::Scal>& fcu, const Vars& var, M& m, bool verbose) {
  auto sem = m.GetSem("initvf");
  struct {
    std::vector<char> buf;
  } * ctx(sem);

  if (sem("zero")) {
    fcu.Reinit(m, 0);
  }
  const std::string init_vf = var.String["init_vf"];
  if (init_vf == "list") {
    if (sem("list-bcast")) {
      if (m.IsRoot()) {
        auto buf = ReadPrimList(var.String["list_path"], verbose);
        ctx->buf = std::vector<char>(
            std::istreambuf_iterator<char>(buf),
            std::istreambuf_iterator<char>());
      }
      m.Bcast(&ctx->buf);
    }
    if (sem("list-local")) {
      std::stringstream list;
      std::copy(
          ctx->buf.begin(), ctx->buf.end(), std::ostream_iterator<char>(list));
      InitVfList(fcu, list, var.Int["list_ls"], var.Int["dim"], m, verbose);
    }
  } else if (init_vf == "hdf") {
    if (sem.Nested()) {
      dump::Hdf<M>::Read(fcu, var.String["init_vf_hdf_path"], m);
    }
  } else if (init_vf == "raw") {
    if (sem.Nested()) {
      const auto meta = dump::Xmf<typename M::Vect>::GetMeta(m);
      dump::Raw<M>::Read(fcu, meta, var.String["init_vf_raw_path"], m);
    }
  } else {
    if (sem("local")) {
      auto func = CreateInitU<M>(var, m.IsRoot());
      func(fcu, m);
    }
  }
  if (sem("comm")) {
    m.Comm(&fcu);
  }
}

// listpath: path to list of primitives b.dat
// fcu: volume fraction field
// fccl: color field
template <class M>
void InitOverlappingComponents(
    std::istream& primlist, const Multi<FieldCell<typename M::Scal>*>& fcu,
    const Multi<FieldCell<typename M::Scal>*>& fccl,
    const GRange<size_t>& layers, const M& m);
