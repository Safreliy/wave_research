"""Independent raw-field endpoint check for matched native L9/L10 runs.

Reads tar members directly; does not import the production native analyser.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import re
import tarfile
from pathlib import Path

import numpy as np


COMMON = ("q.raw", "cs.raw", "vf.raw", "fluxx.raw", "fluxxp.raw",
          "fluxy.raw", "fluxyp.raw", "fluxeb.raw", "body.dat")
VALUES = ("vf", "ebvf", "vx", "vy")


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Archive:
    def __init__(self, path):
        self.path = Path(path)
        self.sha256 = hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.tar = tarfile.open(self.path, "r:gz")
        self.members = {m.name: m for m in self.tar if m.isfile()}
        if len(self.members) != len([m for m in self.tar.getmembers() if m.isfile()]):
            raise ValueError("duplicate tar member")

    def read(self, name):
        stream = self.tar.extractfile(self.members[name])
        if stream is None:
            raise ValueError(f"unreadable member {name}")
        return stream.read()

    def json(self, name):
        return json.loads(self.read(name))

    def field(self, name, shape):
        data = self.read(name)
        if len(data) != 8 * math.prod(shape):
            raise ValueError(f"wrong raw field size {name}")
        value = np.frombuffer(data, dtype="<f8").reshape(shape)
        if not np.isfinite(value).all():
            raise ValueError(f"nonfinite raw field {name}")
        return value

    def endpoint(self, prefix, shape):
        choices = sorted(
            name for name in self.members
            if name.startswith(prefix + "/segments/")
            and re.search(r"/vf_\d{4}\.raw$", name)
        )
        if not choices:
            raise ValueError(f"missing native VF snapshots {prefix}")
        last = choices[-1]
        number = re.search(r"vf_(\d{4})\.raw$", last).group(1)
        common = last[:last.rfind("vf_")]
        fields = {name: self.field(common + name + "_" + number + ".raw", shape)
                  for name in VALUES}
        return {"member_prefix": common, "index": int(number), "fields": fields}

    def close(self):
        self.tar.close()


def velocity_error(fields, reference, q):
    difference = (fields["vx"]-reference["vx"])**2 + (fields["vy"]-reference["vy"])**2
    energy = reference["vx"]**2 + reference["vy"]**2
    return float(np.sqrt(np.sum(q*difference, dtype=np.float64)
                         / np.sum(q*energy, dtype=np.float64)))


def depth_error(fields, reference, h):
    depth = h * np.sum(fields["vf"] * fields["ebvf"], axis=0, dtype=np.float64)
    ref = h * np.sum(reference["vf"] * reference["ebvf"], axis=0, dtype=np.float64)
    return float(np.linalg.norm(depth-ref) / np.linalg.norm(ref-ref.mean()))


def run(case, baseline_outputs, matched_outputs, original_inputs, matched_inputs):
    base_prefix = case
    new_prefix = case + "_matched"
    original_protocol = baseline_outputs.json(base_prefix + "/protocol.json")
    matched_protocol = matched_outputs.json(new_prefix + "/protocol.json")
    if original_protocol["geometry"] != matched_protocol["geometry"]:
        raise ValueError("different declared native geometry")
    if matched_protocol.get("physical_trace") != "parent_hermite_matched":
        raise ValueError("matched trace mode absent")
    geometry = original_protocol["geometry"]
    shape = (geometry["ny"], geometry["nx"])
    h = geometry["period"] / geometry["nx"]
    target = original_protocol["target_time_one_tenth_period"]
    if abs(matched_protocol["target_time_one_tenth_period"]-target) > 1e-14:
        raise ValueError("different target physical time")
    status = {}
    for label, archive, prefix in (
        ("exact", baseline_outputs, base_prefix + "/runs/full/exact_initial_means"),
        ("control", baseline_outputs, base_prefix + "/runs/full/bilinear_centroid"),
        ("matched", matched_outputs, new_prefix + "/runs/full/fitted"),
    ):
        state = archive.json(prefix + "/status.json")
        if (state["state"] != "complete"
                or abs(state["checkpoint"]["time"]-target) > 1e-12
                or abs(state["target_time"]-target) > 1e-12):
            raise ValueError(f"incomplete or unequal physical endpoint {label}")
        status[label] = {"time": state["checkpoint"]["time"],
                         "state": state["state"],
                         "solver_sha256": state["runtime_fingerprint"]["solver_sha256"],
                         "solver_library_sha256": state["runtime_fingerprint"]["solver_library_sha256"]}
    if len({v["solver_sha256"] for v in status.values()}) != 1:
        raise ValueError("solver binary differs between native branches")
    if len({v["solver_library_sha256"] for v in status.values()}) != 1:
        raise ValueError("solver library differs between native branches")
    old_input = base_prefix + "/exact_initial_means/"
    new_input = new_prefix + "/fitted/"
    common_hashes = {}
    for name in COMMON:
        old, new = original_inputs.read(old_input + name), matched_inputs.read(new_input + name)
        if old != new:
            raise ValueError(f"native common input differs: {name}")
        common_hashes[name] = sha(old)
    old_q = original_inputs.field(old_input + "q.raw", shape)
    new_q = matched_inputs.field(new_input + "q.raw", shape)
    gas = old_q == 0
    for name in ("vx.raw", "vy.raw"):
        original = original_inputs.field(old_input + name, shape)
        candidate = matched_inputs.field(new_input + name, shape)
        if not np.array_equal(original[gas], candidate[gas]):
            raise ValueError(f"gas input differs: {name}")
    if not np.array_equal(old_q, new_q):
        raise ValueError("liquid q differs")
    endpoints = {
        "exact": baseline_outputs.endpoint(base_prefix + "/runs/full/exact_initial_means", shape),
        "control": baseline_outputs.endpoint(base_prefix + "/runs/full/bilinear_centroid", shape),
        "matched": matched_outputs.endpoint(new_prefix + "/runs/full/fitted", shape),
    }
    ref = endpoints["exact"]["fields"]
    q_reference = ref["vf"] * ref["ebvf"]
    values = {}
    for name in ("control", "matched"):
        fields = endpoints[name]["fields"]
        values[name] = {
            "velocity_relative_l2": velocity_error(fields, ref, q_reference),
            "wave_normalized_depth_relative_l2": depth_error(fields, ref, h),
            "endpoint_snapshot_index": endpoints[name]["index"],
        }
    values["exact"] = {"endpoint_snapshot_index": endpoints["exact"]["index"]}
    return {
        "case": case,
        "grid": shape,
        "physical_target_time": target,
        "status": status,
        "common_input_sha256": common_hashes,
        "gas_input_bitwise_identical": True,
        "native_reference_q_weight": "vf_exact * ebvf_exact",
        "metrics": values,
        "matched_vs_control_velocity_gain": values["control"]["velocity_relative_l2"]
                                              / values["matched"]["velocity_relative_l2"],
        "matched_vs_control_depth_gain": values["control"]["wave_normalized_depth_relative_l2"]
                                           / values["matched"]["wave_normalized_depth_relative_l2"],
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--case", choices=("flat_native_L9", "flat_native_L10"), required=True)
    p.add_argument("--baseline-outputs", type=Path, required=True)
    p.add_argument("--matched-outputs", type=Path, required=True)
    p.add_argument("--original-inputs", type=Path, required=True)
    p.add_argument("--matched-inputs", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    archives = [Archive(path) for path in (args.baseline_outputs, args.matched_outputs,
                                          args.original_inputs, args.matched_inputs)]
    try:
        result = run(args.case, *archives)
        result["schema"] = "independent-matched-native-endpoint-audit-v1"
        result["archive_sha256"] = {
            name: archive.sha256 for name, archive in zip(
                ("baseline_outputs", "matched_outputs", "original_inputs", "matched_inputs"),
                archives
            )
        }
        result["code_sha256"] = sha(Path(__file__).read_bytes())
    finally:
        for archive in archives:
            archive.close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"case": args.case,
                      "matched": result["metrics"]["matched"],
                      "control": result["metrics"]["control"]}))


if __name__ == "__main__":
    main()
