"""Package an explicit SHA allowlist of the matched-operator evidence."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.with_name(ROOT.name + "_evidence.tar.gz")
TOP_LEVEL = (
    "PREDECLARED_PROTOCOL.md", "MATCHED_EDGE_AMENDMENT.md",
    "HELDOUT_PROTOCOL.md", "ASSESSMENT.md", "diagnostic_oracle.json",
    "native_endpoint_L9_independent.json", "native_endpoint_L10_independent.json",
    "audit_matched_native_independent.py", "audit_method_campaign.py",
    "invariant_regression_audit.json", "EXTERNAL_NATIVE_ARCHIVES.json",
    "package_method_evidence.py",
)
SNAPSHOTS = ("source_snapshot", "diagnostic_source_snapshot",
             "matched_source_snapshot", "heldout_source_snapshot",
             "native_builder_snapshot")
RESULTS = ("declared", "matched_declared", "heldout_mode7",
           "pilot", "matched_pilot")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safe_path(relative):
    path = PurePosixPath(relative)
    if (path.is_absolute() or ".." in path.parts or "__pycache__" in path.parts
            or not path.parts or "\\" in relative):
        raise ValueError(f"unsafe evidence path: {relative}")
    return relative


def add_bytes(tar, name, content):
    info = tarfile.TarInfo(ROOT.name + "/" + name)
    info.size = len(content)
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ""
    info.mode = 0o644
    tar.addfile(info, io.BytesIO(content))


def main():
    if OUTPUT.exists():
        raise FileExistsError(OUTPUT)
    files = set(TOP_LEVEL)
    for folder_name in SNAPSHOTS:
        folder = ROOT / folder_name
        manifest_path = folder / "SNAPSHOT_MANIFEST.json"
        files.add(folder_name + "/SNAPSHOT_MANIFEST.json")
        manifest = json.loads(manifest_path.read_text())
        for row in manifest["files"]:
            relative = folder_name + "/" + safe_path(row["path"])
            if sha(ROOT / relative) != row["sha256"]:
                raise ValueError(f"snapshot hash mismatch: {relative}")
            files.add(relative)
    for folder_name in RESULTS:
        folder = ROOT / folder_name
        report = json.loads((folder / "result.json").read_text())
        files.add(folder_name + "/result.json")
        for row in report["rows"]:
            relative = folder_name + "/" + safe_path(row["arrays"])
            if sha(ROOT / relative) != row["arrays_sha256"]:
                raise ValueError(f"result array hash mismatch: {relative}")
            files.add(relative)
    allowlist = []
    for relative in sorted(files):
        safe_path(relative)
        source = ROOT / relative
        if not source.is_file() or source.is_symlink():
            raise ValueError(f"not a regular evidence file: {relative}")
        allowlist.append({"path": relative, "size": source.stat().st_size,
                          "sha256": sha(source)})
    record = {"schema": "matched-operator-evidence-allowlist-v1",
              "scope": "executed-source snapshots, analytic tests, audits; native raw archives externally hashed",
              "files": allowlist}
    content = (json.dumps(record, indent=2) + "\n").encode()
    outside = ROOT / "EVIDENCE_ALLOWLIST.json"
    if outside.exists():
        raise FileExistsError(outside)
    outside.write_bytes(content)
    with OUTPUT.open("xb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w") as tar:
                for row in allowlist:
                    add_bytes(tar, row["path"], (ROOT / row["path"]).read_bytes())
                add_bytes(tar, "allowlist.json", content)
    print(json.dumps({"output": str(OUTPUT), "files": len(allowlist),
                      "tar_members": len(allowlist)+1,
                      "size": OUTPUT.stat().st_size, "sha256": sha(OUTPUT)}))


if __name__ == "__main__":
    main()
