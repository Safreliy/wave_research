# Held-out flat-strip transition check (declared before execution)

Keep the matched operator, blend `beta(s)=3s²−2s³`, source-jet integration,
source sampling, tolerances and full/cut edge treatment unchanged. Evaluate
an independent harmonic mode 7 with potential amplitude 0.02, length 64,
native vertical origin and embedded-bed offset, source 512 nodes, trace factor
8. Use nx 512 and 1024 and top-row liquid fractions 0.3, 0.7, 0.99: six
cases total. These fractions stress the transition toward the original
Cartesian edge mean at `d≈h`, where the first matrix did not sample densely.

For each case compute the same analytic liquid-phase mean reference, the
linear physical-trace fitted method, isolated parent-chord Hermite method,
matched parent-chord Hermite method, and each method's same-psi bilinear
centroid control. Report top-row and full-liquid q-weighted relative L2,
momentum closure, and execution time for every case. Record input q and
per-field arrays. Do not select or tune cases based on errors. The test is
flat analytic initialisation only; it does not validate native dynamics or
curved interfaces. Preserve an exact executed-source snapshot before runs.
