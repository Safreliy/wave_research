# Matched flat-surface edge intervention (fixed before comparative run)

The first 15-case matrix and six-case oracle diagnostic are already frozen.
The isolated parent-chord Hermite trace improves some cases but degrades others.
The oracle diagnostic identifies an independent Cartesian-edge integral error
which survives exact vertex values and exact gradients and is divided by thin
top-row liquid fraction. This amendment defines a new method before evaluating
it on the same 15 cases, retaining both old methods as controls.

For a flat upper boundary, each receiver horizontal edge receives a source
boundary jet average `J(d)=<H>−d<N>+d²<NN>/2`, where `d` is its distance below
the surface, `H` is the same parent-chord cubic used on the physical boundary,
`N` is its chord-normal derivative from the supplied streamfunction gradient,
and `NN` is the supplied second normal derivative. `H` is integrated exactly
on each source chord restriction, while `N` and `NN` are integrated exactly
for their declared piecewise-linear interpolation. No analytic solution or
oracle gradient enters this candidate.

At `s=d/h` in [0,1], blend with the original shared Cartesian cubic mean using
`beta(s)=3s²−2s³`: `I=(1−beta)J+beta I_C`. This gives `beta(0)=beta'(0)=0`,
`beta(1)=1`, `beta'(1)=0`. At deeper edges retain `I_C`. Use exactly this
same mean on a Cartesian edge shared by a cut cell and its full neighbour.
Physical edges continue to use restrictions of `H`. A nonflat upper boundary
raises an explicit error; there is no implicit fallback or curved claim.

Run the same 15 flat analytic cases from PREDECLARED_PROTOCOL.md. Compare
linear, isolated parent Hermite, and matched parent Hermite against exact
liquid-phase means and same-psi centroid controls. Report all cases, q-weighted
all-liquid and top-only errors, closure, runtime, and failures. No gate may be
relaxed or case removed after observing an error. Add independent constant/
linear reproduction, periodic seam, C1 blend, and conservation tests. Freeze
the exact executed source tree before launching the declared matrix.
