# Matched flat-boundary transfer: evidence and limits

The opt-in `parent_hermite_matched` transfer uses one parent-chord cubic `H`
for every physical surface crossing and cut-edge restriction. For horizontal
receiver edges within one cell width of a flat surface, it blends the original
shared Cartesian cubic mean with the source-derived normal jet
`<H> - d<N> + d²<NN>/2`, using Cartesian weight `3(d/h)² - 2(d/h)³`.
The same blended mean enters both full and cut cells. All source quantities
come from the prescribed boundary data; analytic interior values and oracle
gradients appear only in the diagnostic/reference scripts. The default
`linear` mode is unchanged. Curved upper boundaries raise an explicit error
in the matched mode.

## Analytic initial-state results

The preregistered 15 flat harmonic cases (`PREDECLARED_PROTOCOL.md` and
`MATCHED_EDGE_AMENDMENT.md`) cover nx 128/256 with mode 4 and nx 512/1024
with the native benchmark mode 16, including top-row q from 1e-5 to 0.1.
The matched method has lower top-row relative velocity L2 and lower
all-liquid q-weighted relative L2 than both the linear and isolated physical
Hermite operators in all 15 cases. Its largest top-row relative L2 is
`5.1532e-5`; largest moment-closure residual is `2.60e-15`. For the native
mode-16 geometry at the fixed 6.25e-5 physical top strip:

| Grid | Top-row error: linear / isolated Hermite / matched | All-liquid q-weighted error: linear / matched |
|---|---:|---:|
| nx 512, q 0.0005 | 0.185698 / 0.158329 / 0.00003702 | 0.00298712 / 0.00142031 |
| nx 1024, q 0.001 | 0.333552 / 0.0104745 / 0.00003711 | 0.00469958 / 0.000353774 |

The six held-out mode-7 cases (`HELDOUT_PROTOCOL.md`) cover nx 512/1024
and q 0.3/0.7/0.99, with no operator retuning. Matched beats linear and its
own same-streamfunction bilinear-centroid control in all six for top-row and
all-liquid q-weighted error. Its all-liquid gain over that centroid control
is 3.73–32.07×. At q 0.99 it is about 0.2% worse than isolated Hermite on
the top-row metric, consistent with the blend approaching the Cartesian
representation. There is no claim of uniform dominance over that ablation.

The six-case oracle decomposition is diagnostic, not a candidate method.
For manufactured nx 128, q 1e-5, the isolated Hermite top physical-edge
interpolation error is about `2.1e-10` in the edge-mean L2, while the
adjacent Cartesian edge retains about `1.53e-4` error with finite-difference
gradients and `1.4e-5` even with analytic vertex gradients. Dividing their
unmatched difference by a thin liquid volume explains the failure of
physical-trace refinement alone. The matched jet makes both horizontal
edge representations coincide as d tends to zero; the smooth blend gives
Cartesian mismatch weight `O((d/h)²)` near that boundary.

## Native same-grid propagation

The frozen Aphros L9/L10 full-step runs compare matched input against the
existing practical bilinear-centroid input and exact analytic **initial**
phase-mean reference branch. The reference is a same-grid numerical trajectory,
not an exact Navier–Stokes solution. All branches reach physical time
`0.5250717657631933`, use the same solver binary/library and identical
serialized q/cs/vf/face-flux/body inputs; candidate and exact gas velocity
inputs are bitwise equal. An independent script reads final VF/EBVF/VX/VY
raw fields directly from the frozen archives and reproduces:

| Grid | Velocity error matched / control | Velocity gain | Wave-normalised depth error matched / control | Depth gain |
|---|---:|---:|---:|---:|
| L9, nx 512 | 0.00175849 / 0.01386093 | 7.88× | 3.9263e-5 / 0.00255281 | 65.0× |
| L10, nx 1024 | 0.000434603 / 0.00425970 | 9.80× | 7.3386e-6 / 0.000541771 | 73.8× |

These results establish a bounded, practically relevant same-grid improvement
for the flat harmonic initialisation test. They do not establish physical
trajectory accuracy, curved/free-surface performance, breaking-wave
convergence, or source BIE error. The blended operator still inherits
normal-jet interpolation and Cartesian interior errors, and floating-point
cancellation limits arbitrarily small liquid fractions.

## Provenance and reproduction

Each campaign ran from a separate immutable-by-convention source snapshot:
`source_snapshot/` (isolated Hermite), `diagnostic_source_snapshot/` (oracle
decomposition), `matched_source_snapshot/` (15-case comparison), and
`heldout_source_snapshot/` (six held-out cases). Each contains
`SNAPSHOT_MANIFEST.json` and its actual executed files. The native input
builder is frozen separately in `native_builder_snapshot/`; its L9/L10
local preparation smoke tests passed all preflights and showed bit-identical
common inputs and gas values against archived originals. The independent
native raw checker is `audit_matched_native_independent.py`; its outputs are
`native_endpoint_L9_independent.json` and `native_endpoint_L10_independent.json`.
`METHOD_CAMPAIGN_MANIFEST.json` lists hashes of these local records and the
external frozen native input/output archives. Do not substitute the earlier
`builder_smoke_*` directories for the actual native inputs.
