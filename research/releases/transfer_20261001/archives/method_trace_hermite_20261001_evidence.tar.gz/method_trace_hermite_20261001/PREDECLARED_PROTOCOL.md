# Parent-chord Hermite trace experiment (declared before runs)

This is an isolated CPU method experiment. It does not alter the frozen article,
published evidence package, Aphros runs, or the default linear physical trace.

## Operator and invariants

For every straight segment of the receiver polygon, use one cubic Hermite
streamfunction `H_j(t)` with the two endpoint values and the endpoint
directional derivatives `grad(psi) dot Delta_j`. Evaluate this same function at
Shortley–Weller boundary crossings, exterior normal-continuation feet, cut
polygon boundary vertices, and in exact restrictions of physical-edge line
integrals. Retain existing shared Cartesian-edge Hermite integrals. Correct the
surface streamfunction constant so the complete polygonal Hermite horizontal
moment equals the BIE source horizontal momentum. Reject a materially
incompatible vertical momentum; do not repair it numerically.

The implementation must preserve cubic endpoint value/slope, additive
subdivision of restricted integrals, constant-shift behavior, the source
horizontal target, and full-cell/cut-cell moment closure. The default `linear`
mode must still reproduce existing behavior.

## Analytic comparison, fixed before results

Use harmonic potential flow on a flat bed and surface. Compare exact analytic
liquid-phase cell means, the current linear-trace fitted method, the new
parent-Hermite fitted method, and the same-field bilinear streamfunction curl
at actual liquid centroids. Report both unweighted and liquid-fraction-weighted
relative L2 errors for all liquid cells and cut cells, as well as maximum
pointwise cut-row error, closure, runtime, and source/trace momentum mismatch.
No case selection based on the resulting velocity error.

Families:

1. Existing manufactured harmonic: length 64, depth 4, Fourier mode 4,
   potential amplitude 1, nx 128 and 256, top-row q in {0.001, 0.01, 0.1};
   q=1e-5 is a declared additional conditioning stress if finite/resolved.
2. Native benchmark harmonic: length 64, mode 16, depth 0.97006249, potential
   amplitude 0.02, native vertical origin and bed offset, nx 512 and 1024,
   with a fixed physical top strip of 6.25e-5 (q=0.0005 and 0.001). Also
   test q in {0.001, 0.01, 0.1} on affordable grids where source geometry
   and receiver containment permit it.

Source trace sampling is 256 nodes for manufactured and 512 nodes for native.
Begin with geometry refinement factors 8 and 16 respectively (native nx512
factor 8, nx1024 factor 8), exactly as the existing benchmark. Follow-up
refinement is diagnostic only and must be labeled as such. The reference is
analytic mean of the prescribed harmonic field; this test does not establish
dynamic physical accuracy or curved-geometry convergence.

All executed source files, parameters, library versions, and output arrays must
be frozen and SHA-256 indexed in a new result directory after the runs.
