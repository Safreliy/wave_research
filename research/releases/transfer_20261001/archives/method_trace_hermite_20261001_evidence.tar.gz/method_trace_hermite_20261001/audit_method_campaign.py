"""Recheck frozen source, arrays, and default-mode compatibility."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    snapshots = {}
    for name in ("source_snapshot", "diagnostic_source_snapshot",
                 "matched_source_snapshot", "heldout_source_snapshot",
                 "native_builder_snapshot"):
        folder = ROOT / name
        manifest = json.loads((folder / "SNAPSHOT_MANIFEST.json").read_text())
        if not all(digest(folder / row["path"]) == row["sha256"]
                   for row in manifest["files"]):
            raise ValueError(f"snapshot source changed: {name}")
        snapshots[name] = len(manifest["files"])
    arrays_checked = {}
    reports = {}
    for name in ("declared", "matched_declared", "heldout_mode7",
                 "pilot", "matched_pilot"):
        folder = ROOT / name
        report = json.loads((folder / "result.json").read_text())
        for row in report["rows"]:
            if digest(folder / row["arrays"]) != row["arrays_sha256"]:
                raise ValueError(f"saved array hash changed: {name}/{row['arrays']}")
        arrays_checked[name] = len(report["rows"])
        reports[name] = report
    old = {row["case"]: row for row in reports["declared"]["rows"]}
    common = ("q", "exact_phase_mean", "linear_phase_mean",
              "linear_same_psi_centroid", "parent_hermite_phase_mean",
              "parent_hermite_same_psi_centroid")
    max_difference = 0.0
    for row in reports["matched_declared"]["rows"]:
        prior = old[row["case"]]
        with np.load(ROOT / "declared" / prior["arrays"]) as before, \
             np.load(ROOT / "matched_declared" / row["arrays"]) as after:
            for key in common:
                if not np.array_equal(before[key], after[key]):
                    raise ValueError(f"default/isolated Hermite array changed: {row['case']}/{key}")
                max_difference = max(max_difference,
                                     float(np.max(np.abs(before[key]-after[key]))))
    tests = {}
    for name in ("source_snapshot", "matched_source_snapshot"):
        script = ROOT / name / "research/gpu_port/test_physical_trace.py"
        completed = subprocess.run([sys.executable, str(script)], check=True,
                                   capture_output=True, text=True)
        tests[name] = completed.stdout.strip()
    current = Path(__file__).resolve().parents[2] / "gpu_port/test_physical_trace.py"
    if current.is_file():
        completed = subprocess.run([sys.executable, str(current)], check=True,
                                   capture_output=True, text=True)
        tests["current_negative_curved_check"] = completed.stdout.strip()
    matched = reports["matched_declared"]["rows"]
    top_wins = sum(
        row["metrics"]["parent_hermite_matched"]["fitted"]["top_relative_l2"]
        < min(row["metrics"][control]["fitted"]["top_relative_l2"]
              for control in ("linear", "parent_hermite"))
        for row in matched
    )
    all_wins = sum(
        row["metrics"]["parent_hermite_matched"]["fitted"]["all_q_weighted_relative_l2"]
        < min(row["metrics"][control]["fitted"]["all_q_weighted_relative_l2"]
              for control in ("linear", "parent_hermite"))
        for row in matched
    )
    audit = {"schema": "matched-trace-campaign-integrity-v1", "passed": True,
             "snapshot_file_counts": snapshots, "array_case_counts": arrays_checked,
             "common_fields_per_case": len(common),
             "bitwise_compatibility_cases": len(matched),
             "maximum_default_array_absolute_difference": max_difference,
             "invariant_test_outputs": tests,
             "main_top_wins_against_both": top_wins,
             "main_all_liquid_q_weighted_wins_against_both": all_wins,
             "checker_sha256": digest(__file__)}
    output = ROOT / "invariant_regression_audit.json"
    if output.exists():
        raise FileExistsError(output)
    output.write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"passed": True, "snapshots": len(snapshots),
                      "arrays": sum(arrays_checked.values()),
                      "bitwise_cases": len(matched)}))


if __name__ == "__main__":
    main()
